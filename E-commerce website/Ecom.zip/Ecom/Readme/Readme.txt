

Database Name: shop_db 

Developed by Yash Jaiswal


Instructions: How to Run?
Copy the project file and head over to your XAMPP directory.
There you’ll find a folder naming “htdocs”.
Inside the “htdocs” folder, paste the project folder.
Open your favorite browser.
Then, go to URL “http://localhost/phpmyadmin“.
Create a Database with a name that is provided inside the “Read me.txt”.
Click on the “Import” tab and choose the database file (.sql).
After setting up all these, go to URL “http://localhost/[ PROJECT_FOLDER_NAME ]/“
check that out and enter in order to use it.



